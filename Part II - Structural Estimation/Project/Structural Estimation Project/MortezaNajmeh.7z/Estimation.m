%%
clear
close all
clc
useGPU = 0;
%%
nSimul = 100000;
%% Load training data
load("Allp.mat")
load('Allm.mat')
training.Allp = Allp;
training.Allm = Allm;

%% Estimation boundry
constrains.LB = [.8 1.01 0]; %% Lower bound
constrains.UB = [.99 5 .01]; %% Upper bound

%% Load Moments

tMoments = false(1,7);

for v = [1 3 4 6] % 1-participation rate 3-conditional mean risky share 4-mean wealth 6-mean wealth at retirement
    tMoments(v) = true;
end
moment.tMoments = tMoments;

targetm = readtable('data_moments.txt'); targetm = targetm{:,:};
moment.targetm = targetm;
%% Estimation
x = point_estimate(training,moment,constrains);

save("data/estimated_point.mat","x")

m = simul(x,nSimul,useGPU,0.0);

disp("Estimated values")
disp(x)
disp("target moments:")
disp(moment.targetm)
disp("Estimated moments:")
disp(m)
